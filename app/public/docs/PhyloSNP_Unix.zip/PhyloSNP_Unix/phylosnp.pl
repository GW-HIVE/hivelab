#!/usr/bin/perl -w

=head1 SYNOPSIS

perl phylosnp.pl [OPTIONS] file1.csv fileN.csv --output-dir=dir

=head1 DESCRIPTION

Combines .csv and .vcf files with sample data for different genomes into a
PHYLIP format discrete character file with a presence/absence vector of SNPs 
for the accession/ID tuples present in the input, and generates a
phylogenetic tree from the data.

Command-line arguments can specify .csv/.vcf file names or directory names.
If a directory name is given, it will be recursively searched for .csv/.vcf files,
which will be added to the processing list in alphabetical order.

Symbolic links to files will be followed.

Symbolic links to directories will NOT be followed.

Files that do not have a .csv or .vcf extension will be ignored.

=head1 OPTIONS

=over

=item --help

Display documentation.

=item --output-dir=DIRNAME

Directory where output will be written ("output" by default)

=item --accession-col=NAME

Name of accession column ("Accession" by default)

=item --position-col=NAME

Name of position column ("Position" by default)

=item --genome-col=NAME

Name of the genome name column ("Name" by default)

=item --replicates=NAME

Number of replicates for bootstrapping (100 by default)

=back

=cut

use strict;
use warnings;

use File::Basename;
use lib dirname(__FILE__) . "/inc";

use File::Copy qw(move);
use File::Find;
use File::Spec;
use File::Which;
use Getopt::Long;
use IPC::Open2;
use Pod::Usage;

use PhyloSNP::Converter;

my %converter_attr = %PhyloSNP::Converter::default_attr;
my $output_dirname = "output";
my $replicates = 100;

my $show_help = 0;
GetOptions("help|?" => \$show_help,
    "output-dir=s" => \$output_dirname,
    "accession-col=s" => \$converter_attr{accession_col},
    "position-col=s" => \$converter_attr{position_col},
    "genome-col=s" => \$converter_attr{genome_name_col},
    "replicates=s" => \$replicates
) or pod2usage(-verbose => 1);
pod2usage(-verbose => 2) if $show_help or !@ARGV;

unless (-d $output_dirname) {
    mkdir $output_dirname or die "Failed to create '$output_dirname' directory";
    print "Created '$output_dirname' directory for output files...\n";
}

my @input_files;
finddepth({
    preprocess => sub {
        # sort directory contents in alphabetical order
        return sort {$a cmp $b} @_;
    },
    wanted => sub {
        # skip unless a regular file with .csv or .vcf extension
        die "Fatal error: $File::Find::name does not exist\n" unless -e;
        -f or return;
        /\.(csv|vcf)$/i or return;
        push @input_files, $File::Find::name;
    }
}, @ARGV);

my $phy_filename = File::Spec->catfile($output_dirname, "input.phy");
print "Combining input data into a discrete character PHYLIP file...\n";
my $converter = PhyloSNP::Converter->new(%converter_attr,
    snp_files => [@input_files]);
$converter->make_discrete_character_phy($phy_filename);

print "Checking for PHYLIP executables...\n";
for (qw(seqboot pars consense retree)) {
    die "Failed to find PHYLIP executables in \$PATH\n" unless defined(which($_));
}

my $cmd;
chdir $output_dirname or die "Failed to cd to '$output_dirname': $!";

phylip_command("seqboot", "input.phy\nd\nr\n$replicates\ny\n5",
    "outfile", "seq_file");
phylip_command("pars", "seq_file\nm\nd\n$replicates\n5\n3\ni\ny",
    "outfile" => "pars_file", "outtree" => "pars_tree");
phylip_command("consense", "pars_tree\nr\ny",
    "outfile" => "consense_file.txt", "outtree" => "consense_tree");
phylip_command("pars", "input.phy\nu\ni\ny\nconsense_tree",
    "outfile" => "pars_file_f", "outtree" => "pars_tree_f");
phylip_command("retree", "y\npars_tree_f\nm\nw\nr\nq",
    "outtree" => "mv_tree.txt");

exit 0;

sub phylip_command {
    my $command = shift;
    my $input = shift;
    my %move_outfiles = @_;

    # terminate command with two newlines (freezes on Windows otherwise)
    $input .= "\n\n";

    # clear output files before running the command
    for my $fn (keys %move_outfiles) {
        if (-e $fn) {
            unlink $fn or die "Failed to delete '$fn': $!";
        }
    }

    my ($inpipe, $outpipe);
    my $pid = open2($outpipe, $inpipe, $command) or die "Failed to launch $command: $!";
    $inpipe->autoflush(1);
    $outpipe->autoflush(1);
    print "Running $command...\n";
    local $SIG{PIPE} = sub { die "Failed to run $command: broken input pipe"; };
    print $inpipe $input;
    close $inpipe or die "Failed to run $command: $!";
    my @output;
    if ($ENV{DEBUG} and $ENV{DEBUG} =~ /y/i) {
        while(<$outpipe>) {
            print "Outpipe says: $_";
        }
    } else {
        @output = <$outpipe>;
    }
    waitpid($pid, 0);
    if ($? >> 8) {
        print @output;
        die "$command terminated with an error";
    }
    close $outpipe;

    for my $fn (keys %move_outfiles) {
        move($fn, $move_outfiles{$fn}) or die "Failed to rename '$fn' to '$move_outfiles{$fn}': $!";
    }
}

#vim: set et ts=4 sts=4:
