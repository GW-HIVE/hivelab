#!/usr/bin/perl -w

=head1 SYNOPSIS

perl shrunk-genomes.pl [OPTIONS] file1.csv fileN.csv --reference-file=ref.fa > shrunk.fa

=head1 DESCRIPTION

Combines .csv and .vcf files with SNP data for different sample and a
reference genome file into a "shrunken" genome file, showing the changed
genomes only for those positions which had an SNP for at least one sample.

Command-line arguments can specify .csv/.vcf file names or directory names.
If a directory name is given, it will be recursively searched for .csv/.vcf files,
which will be added to the processing list in alphabetical order.

Symbolic links to files will be followed.

Symbolic links to directories will NOT be followed.

Files that do not have a .csv or .vcf extension will be ignored.

=head1 OPTIONS

=over

=item --help

Display documentation.

=item --accession-col=NAME

Name of accession column ("Accession" by default; not used for FASTA
format references)

=item --position-col=NAME

Name of position column ("Position" by default)

=item --genome-col=NAME

Name of the sample genome name column ("Name" by default)

=item --change-col=NAME

Name of the SNP change column ("Change" by default)

=item --letter-col=NAME

Name of the reference genome letter column ("Letter" by default)

=item --reference-file=NAME

Name of reference genome file; needs to be in FASTA or CSV format

=item --reference-name=NAME

Name of a specific reference inside a FASTA file with multiple references

=item --reference-col=NAME

Column containing reference names used in the FASTA reference genome.

=item --reference-map=NAME

CSV file with two columns: the values used in the --reference-col column
in the input files, and the names used in the FASTA reference genome.
NOTE: if you use --reference-map option, you must also specify --reference-col.

=item --position-delta

Position range around each SNP to output (0 by default, so only
positions that have an SNP are output).

=back

=cut

use strict;
use warnings;

use File::Basename;
use lib dirname(__FILE__) . "/inc";

use File::Find;
use Getopt::Long;
use Pod::Usage;

use PhyloSNP::Converter;

my %converter_attr = %PhyloSNP::Converter::default_attr;

my $reference_filename = "";
my $reference_name = undef;
my $show_help = 0;
GetOptions("help|?" => \$show_help,
    "position-col=s" => \$converter_attr{position_col},
    "genome-col=s" => \$converter_attr{genome_name_col},
    "change-col=s" => \$converter_attr{change_col},
    "letter-col=s" => \$converter_attr{letter_col},
    "reference-file=s" => \$reference_filename,
    "reference-name=s" => \$converter_attr{reference_name},
    "reference-col=s" => \$converter_attr{reference_col},
    "reference-map=s" => \$converter_attr{reference_map_file},
    "position-delta=n" => \$converter_attr{position_delta}
) or pod2usage(-verbose => 1);
pod2usage(-verbose => 2) if $show_help or !$reference_filename or !@ARGV;

my @snp_files;
finddepth({
    preprocess => sub {
        # sort directory contents in alphabetical order
        return sort {$a cmp $b} @_;
    },
    wanted => sub {
        # skip unless a regular file with .csv or .vcf extension
        die "Fatal error: $File::Find::name does not exist\n" unless -e;
        -f or return;
        /\.(csv|vcf)$/i or return;
        push @snp_files, $File::Find::name;
    }
}, @ARGV);

my $converter = PhyloSNP::Converter->new(%converter_attr,
    snp_files => \@snp_files,
    reference_file => $reference_filename);

warn "Shrinking genomes...\n";
$converter->make_shrunk_genomes("", \*STDOUT);

#vim: set et ts=4 sts=4:
