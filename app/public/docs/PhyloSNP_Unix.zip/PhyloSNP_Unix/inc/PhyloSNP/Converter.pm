=head1 SYNOPSIS

 my $converter = PhyloSNP::Converter->new(
     snp_files => [ foo.csv, bar.csv ],
     accession_col => "Acc",
     position_col => "Pos"
 );
 $converter->make_discrete_character_phy("char.phy");

=head1 FUNCTIONS

=head2 new (%attributes)

=head2 make_discrete_character_phy ($filename, $filehandle)

Combines .csv and .vcf files with sample data for different genomes into a
PHYLIP format discrete character file with a presence/absence vector of SNPs 
for the accession/ID tuples present in the input.

=cut

package PhyloSNP::Converter;

use strict;
use warnings;

use Carp;
use File::Find;
use Text::CSV;

use PhyloSNP::Parser::CSV;
use PhyloSNP::Parser::FASTA;

our %default_attr = (
    snp_files => [],
    reference_file => undef,
    reference_name => undef,
    reference_col => undef,
    reference_map_file => undef,
    accession_col => "Accession",
    position_col => "Position",
    genome_name_col => "Name",
    change_col => "Change",
    letter_col => "Letter",
    position_delta => 0,
);

our @required_attr = qw(snp_files position_col);

sub new {
    my $class = shift;
    my %attr = @_;
    my $self = {%default_attr};
    for (keys %attr) {
        confess "Unknown attribute '$_'" unless exists $default_attr{$_};
        $self->{$_} = $attr{$_};
    }
    for (@required_attr) {
        confess "Missing required attribute '$_'" unless defined $self->{$_};
    }
    bless $self, $class;
    return $self;
}

sub _get_file_format {
    local $_ = shift;
    if (/\.(csv|vcf)$/i) {
        return "CSV";
    } elsif (/\.(fa|fas|fsa|fasta|seq|fna|ffn|frn)$/i) {
        return "FASTA";
    }
    return "";
}

sub _load_reference_map {
    my $self = shift;

    $self->{reference_map} = {};

    my @header;
    my $parser = PhyloSNP::Parser::CSV->new(
        header_callback => sub {
            @header = @_;
            confess "Map file must have two columns\n" unless scalar(@header) == 2;
        },
        callback => sub {
            my $data = shift;
            $self->{reference_map}->{$data->{$header[0]}} = $data->{$header[1]};
        }
    );

    $parser->parse($self->{reference_map_file});
}

sub _get_sites_genomes {
    my $self = shift;
    my $sites = shift;
    my $genomes = shift;
    my $header_callback = shift;
    my $want_change = shift;
    my $want_reference = shift;

    my @required = ($self->{position_col});
    if ($want_change) {
        push @required, $self->{change_col};
    }
    if ($want_reference and defined $self->{reference_col}) {
        push @required, $self->{reference_col};
    }

    my $parser = PhyloSNP::Parser::CSV->new(
        required => \@required,
        optional => [$self->{accession_col}, $self->{genome_name_col}],
        preprocess => {
            $self->{position_col} => sub { $_ += 0 }, # force position to be interpreted as an integer
            $self->{accession_col} => sub { defined($_) ? $_ : "" },
            $self->{genome_name_col} => sub { defined($_) ? $_ : "" }
        },
        header_callback => $header_callback,
        callback => sub {
            my $data = shift;
            my %args = @_;

            my $pos = $data->{$self->{position_col}};
            my $acc = "";
            if ($want_reference) {
                if (defined $self->{reference_col}) {
                    $acc = $data->{$self->{reference_col}};
                    if (scalar $self->{reference_map}) {
                        confess "Column '$acc' is not mapped in reference name map file\n" unless defined $self->{reference_map}->{$acc};
                        $acc = $self->{reference_map}->{$acc};
                    }
                } else {
                    $acc = $self->{reference_name};
                }
            } else {
                $acc = $data->{$self->{accession_col}};
            }
            my $genome_name = $data->{$self->{genome_name_col}};

            my $sitekey = $acc . $pos;
            my $genomekey = $args{filename} . $genome_name;

            $sites->{$acc} = {} unless $sites->{$acc};
            $sites->{$acc}->{$pos} = {} unless $sites->{$acc}->{$pos};
            $sites->{$acc}->{$pos}->{$genomekey} = $want_change ? $data->{$self->{change_col}} : 1;

            unless ($genomes->{$genomekey}) {
                $genomes->{$genomekey} = { filename => $args{filename}, genome_name => $genome_name };
            }
        }
    );

    for (@{$self->{snp_files}}) {
        $parser->parse($_);
    }
}

sub make_discrete_character_phy {
    my $self = shift;
    my $fn = shift;
    my $fh = shift;
    unless ($fh) {
        open($fh, ">", $fn) or confess "Cannot create '$fn': $!\n";
    }

    my %sites = ();
    my %genomes = ();
    $self->_get_sites_genomes(\%sites, \%genomes);

    my @site_accs = sort keys %sites;
    my $num_site_acc_positions = 0;
    my %site_acc_positions;
    for my $acc (@site_accs) {
        my @site_acc_positions = sort { $a <=> $b } keys %{$sites{$acc}};
        $num_site_acc_positions += @site_acc_positions;
        $site_acc_positions{$acc} = \@site_acc_positions;
    }
    my @genomekeys = sort keys %genomes;

    # phylip header
    print $fh "    ", scalar(@genomekeys), "   $num_site_acc_positions\n";

    for my $genomekey (@genomekeys) {
        # sample name is a 10-character field, space-padded at the right
        my $sample_name = $genomes{$genomekey}->{genome_name};
        unless ($sample_name) {
            $sample_name = $genomes{$genomekey}->{filename};
            $sample_name =~ s/^\.\///;
            $sample_name =~ s/\.(csv|vcf)$//i;
        }
        # phylip tools don't like special characters in species names
        $sample_name =~ s/[():;,\[\]]//g;
        $sample_name = substr $sample_name . " ", -11, -1;
        $sample_name = $sample_name . (' ' x (10 - length($sample_name))) if length $sample_name < 10;

        print $fh $sample_name;
        for my $acc (@site_accs) {
            for my $pos (@{$site_acc_positions{$acc}}) {
                print $fh $sites{$acc}->{$pos}->{$genomekey} ? 1 : 0;
            }
        }
        print $fh "\n";
    }

    close $fh;
}

sub make_shrunk_genomes {
    my $self = shift;
    my $fn = shift;
    my $fh = shift;
    unless ($fh) {
        open($fh, ">", $fn) or confess "Cannot create '$fn': $!\n";
    }

    my $ref_format = _get_file_format($self->{reference_file});

    my %sites;
    my %genomes;
    my $have_accession_col = 0;
    my $want_reference = 0;

    if ($ref_format eq "FASTA") {
        $want_reference = ($self->{reference_name} or $self->{reference_col});
        if ($self->{reference_map_file}) {
            $self->_load_reference_map();
        }
    }

    $self->_get_sites_genomes(\%sites, \%genomes, sub {
        return if $want_reference;
        return if $have_accession_col;
        for (@_) {
            if ($_ eq $self->{accession_col}) {
                $have_accession_col = 1;
                return;
            }
        }
    }, 1, $want_reference);

    my %site_acc_positions = map { $_ => [sort { $a <=> $b } keys %{$sites{$_}}] } keys %sites;
    my @genomekeys = sort keys %genomes;
    my %shrunk = map { $_ => "" } @genomekeys;
    my $shrunk_reference = "";

    my ($prev_pos, $prev_acc, $prev_site_pos);

    my $ref_callback = sub {
        my $data = shift;
        my %args = @_;

        my $pos = $data->{$self->{position_col}};
        my $acc = "";
        if ($ref_format eq "CSV") {
            $acc = $data->{$self->{accession_col}};
            if (defined $prev_pos and $acc eq $prev_acc and $pos <= $prev_pos) {
                confess "Positions $prev_pos, $pos not in ascending order in '$self->{reference_file}'\n";
            }
        } elsif ($ref_format eq "FASTA" and $want_reference) {
            $acc = $args{sequence_name};
        }
        my $letter = $data->{$self->{letter_col}};

        $prev_pos = $pos;
        $prev_acc = $acc;

        my $site_positions = $site_acc_positions{$acc};
        return unless $site_positions;

        while(1) {
            my $site_pos = $site_positions->[0];
            return unless defined $site_pos;
            return if $pos < $site_pos - $self->{position_delta};

            last if $pos <= $site_pos + $self->{position_delta};

            shift @$site_positions;
        }

        for my $genomekey(@genomekeys) {
            my $change = $sites{$acc}->{$pos}->{$genomekey};
            unless (defined $change) {
                $shrunk{$genomekey} .= $letter;
                next;
            }

            if (length($change) > 1) {
                my ($from, $to) = split /[|\/]/, $change;
                unless ($from eq $letter and length($to) == 1) {
                    my $msg = "Invalid change '$change' at";
                    if ($have_accession_col) {
                      $msg .= "accession '$acc',";
                    } elsif ($ref_format eq "FASTA" and $want_reference) {
                        $msg .= "reference sequence '$acc',"
                    }
                    confess "$msg position '$pos' in '$genomes{$genomekey}->{filename}' (expected change from '$letter')\n";
                }
                $shrunk{$genomekey} .= $to;
            } else {
                $shrunk{$genomekey} .= $change;
            }
        }
        $shrunk_reference .= $letter;
    };

    if ($ref_format eq "CSV") {
        my @required = ($self->{position_col}, $self->{letter_col});
        if ($have_accession_col) {
            push @required, $self->{accession_col};
        }
        my $refcsv = PhyloSNP::Parser::CSV->new(
            required => \@required,
            optional => [ $self->{accession_col} ],
            preprocess => { $self->{accession_col} => sub { $_ or "" } },
            header_callback => sub {
                my $ref_has_accession_col = 0;
                for (@_) {
                    if ($_ eq $self->{accession_col}) {
                        $ref_has_accession_col = 1;
                        last;
                    }
                }
                if ($have_accession_col != $ref_has_accession_col) {
                    confess "Failure: either both the reference file and SNP files must use accession data, or both must not\n";
                }
            },
            callback => $ref_callback
        );
        $refcsv->parse($self->{reference_file});

    } elsif ($ref_format eq "FASTA") {
        # Sanity check: are we using at most one accession code?
        if ($have_accession_col and keys %sites > 1) {
            confess "Failure: multiple accession values for SNP files not supported when a FASTA file is used for the reference genome\n";
        }

        my $num_headers = 0;
        my $reffa = PhyloSNP::Parser::FASTA->new(
            position_col => $self->{position_col},
            letter_col => $self->{letter_col},
            preprocess => {
                $self->{letter_col} => sub {
                    /[ACGTURYKMSWBDHVNX]/ or confess "Letter '$_' in FASTA reference file is not supported\n";
                    return $_;
                }
            },
            header_callback => sub {
                $num_headers++;
                if ($num_headers and !$want_reference) {
                    confess "Reference genome FASTA files with multiple sequences require the specific reference sequence name to be specified. See --reference-name and --reference-col options\n";
                }
            },
            relevant_sequences => $want_reference ? [keys %sites] : undef,
            callback => $ref_callback
        );

        $reffa->parse($self->{reference_file});

    } else {
        confess "Unknown file format: $self->{reference_file}\n";
    }

    for my $acc (keys %sites) {
        if (scalar @{$site_acc_positions{$acc}}) {
            my $msg = "Missing reference letter for";
            if ($have_accession_col) {
                $msg .= " accession '$acc',";
            } elsif ($ref_format eq "FASTA" and $want_reference) {
                $msg .= " reference sequence '$acc',"
            }
            confess "$msg positions " . join(", ",  @{$site_acc_positions{$acc}}) . "\n";
        }
    }

    for my $genomekey(@genomekeys) {
        my $sample_name = $genomes{$genomekey}->{genome_name};
        unless ($sample_name) {
            $sample_name = $genomes{$genomekey}->{filename};
            $sample_name =~ s/^\.\///;
            $sample_name =~ s/\.(csv|vcf)$//i;
        }

        print $fh ">$sample_name\r\n";
        while(1) {
            print $fh substr($shrunk{$genomekey}, 0, 80, ""), "\r\n";
        } continue {
            last unless length $shrunk{$genomekey};
        }
    }

#    print $fh ">original reference (shrunk)\r\n";
#    while(1) {
#        print $fh substr($shrunk_reference, 0, 80, ""), "\r\n";
#    } continue {
#        last unless length $shrunk_reference;
#    }

    close $fh;
}

#vim: set et ts=4 sts=4:
