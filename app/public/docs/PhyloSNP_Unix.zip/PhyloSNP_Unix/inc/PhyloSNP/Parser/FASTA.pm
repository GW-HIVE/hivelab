=head1 SYNOPSIS

 my $parser = PhyloSNP::Parser::FASTA->new(
     first_position => 0,
     header_calback => sub {
        my $header = shift;
        print "Header is '>", $header, "'\n";
    }
     callback => sub {
         my $data = shift;
         print "Letter ", $data->{Letter}, " at position is ", $data->{Position}, "\n";
     }
 $parser->parse("input.fa");

=cut

package PhyloSNP::Parser::FASTA;

use strict;
use warnings;

use Carp;

our %default_attr = (
    callback => undef,
    header_callback => undef,
    relevant_sequences => undef,
    first_position => 1,
    position_col => "Position",
    letter_col => "Letter",
    preprocess => {}
);

our @required_attr = qw(callback);

sub new {
    my $class = shift;
    my %attr = @_;
    my $self = {%default_attr};
    for (keys %attr) {
        die "Unknown attribute '$_'" unless exists $default_attr{$_};
        $self->{$_} = $attr{$_};
    }
    for (@required_attr) {
        die "Missing required attribute '$_'" unless defined $self->{$_};
    }
    bless $self, $class;
    return $self;
}

sub parse {
    my $self = shift;
    my $fn = shift;
    my $fh = shift;

    unless ($fh) {
        open $fh, $fn or confess "Failed to open '$fn'\n";
    }

    my $all_seqs_relevant = 0;
    my %relevant_seqs;
    my $relevant_seqs_num = 0;
    if (defined $self->{relevant_sequences}) {
        %relevant_seqs = map { $_ => 1 } @{$self->{relevant_sequences}};
        $relevant_seqs_num = scalar @{$self->{relevant_sequences}};
    } else {
        $all_seqs_relevant = 1;
    }

    my $position = $self->{first_position};
    my $line = 0;
    my $sequence_name = "";

    while(<$fh>) {
        $line++;
        s/[\r\n]+$//; # platform-independent chomp
        if (s/^>//) {
            # parse header
            $sequence_name = $_;
            unless ($all_seqs_relevant) {
                goto OUT unless $relevant_seqs_num > 0;
                if ($relevant_seqs{$sequence_name}) {
                    $relevant_seqs{$sequence_name} = 0;
                    $relevant_seqs_num--;
                } else {
                    next;
                }
            }
            if ($self->{header_callback}) {
                $self->{header_callback}->($sequence_name);
            }
            $position = $self->{first_position};
        } else {
            tr/a-z/A-Z/;
            my @letters = split //;
            for my $letter (@letters) {
                my $data = {$self->{letter_col} => $letter, $self->{position_col} => $position};
                for my $col (keys %{$self->{preprocess}}) {
                    local $_ = $data->{$col};
                    $data->{$col} = $self->{preprocess}->{$col}($col);
                }
                $self->{callback}->($data, filename => $fn, sequence_name => $sequence_name, line => $line);
                $position++;
            }
        }
    }

  OUT:
    close $fh;
    return $line+1;
}

#vim: set et ts=4 sts=4:
