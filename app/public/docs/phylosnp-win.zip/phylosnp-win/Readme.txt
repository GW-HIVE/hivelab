PhyloSNP: An automated generator of phylogenetic trees from SNP data
Contact: Jamie_Faison@gwmail.gwu.edu, mazumder@gwu.edu

A) Usage: For Unix, type perl phylosnp.pl --help for more help. Generation of trees consists of a two step process. 
Use genome_example.csv for a demonstration of the program and how a merged SNP genome file should be formatted.

1) Select the folder where file(s) are located and choose a file type
	a) File types supported (.csv and .vcf)
		i)   Existing merged files (Merged SNP File) 
		ii)  Positional mutations at genome level (Genome File)
		iii) Positional mutations at gene level (Gene File)
	b) Please ensure that your desired file type contains the following columns:
		i)   Genome: Position (Note: for already merged file, rename this column to pos, as seen in ex)
		ii)  Gene: Accession, Position (See note above, rename columns to acc and pos)

2) Once the proper file type is selected, click 'Submit'. The program will generate a phylogenetic
tree in Newick format and provide the user with the location of the tree file and a file containing the bootstrap
values.

Unix: perl phylosnp.pl dir (or files) > output.phylip. Make sure that output.phylip is exactly as shown or trees
will not generate.

B) Troubleshooting:

1) Program not found: Please ensure that the program dependencies (PHYLIP, Perl) are the proper version and are
installed in the proper directories. Make sure that the versions are also the 32-bit version (x86) of the programs.

2) Perl error: Make sure that the Perl path has been set (default option). To check, open up a command prompt and
type 'perl -h {ENTER}'. If the help file displays, the path has been set correctly. If not, contact your
administrator for assistance.

3) Tree not displaying correctly: Make sure that your file contains the correct columns (see usage). Also ensure
that only .csv files and/or .vcf that contain SNP data for analysis are in the folder that was selected.

4) Trees not generating (Unix): see Unix usage, make sure that the command ends with > output.phylip.