=head1 SYNOPSIS

 my $parser = PhyloSNP::Parser::CSV->new(
     required => [ "position" ],
     optional => [ "accession", "name", "id" ],
     preprocess => {
         "accession" => sub { $_ += 42 },
         "name" => sub { $_ or "xyz" }
     },
     callback => sub {
         my $data = shift;
         print "Position is ", $data->{Position}, "\n";
     }
 );
 $parser->parse("input.csv");

=head1 DESCRIPTION

PhyloSNP::Parser::CSV is designed for parsing CSV files that start with
a header line showing column names. VCF files are also supported.

=head1 FUNCTIONS

=head2 new (%attributes)

Returns a new instance of PhyloSNP::Parser::CSV. The following object
attributes are supported:

=over 4

=item required

Array reference of column names that are required. If one of these columns
is missing, or repeated, or a data line doesn't have any data for it, this
is treated as a fatal error.

Default value: []

=item optional

Array reference of column names that are optional. If one of these columns
is repeated, this is treated as a fatal error.

Default value: []

=item callback

Code reference. Must be specified. Will be called for each data line in the
file with the following arguments:

    $data, "filename" => $filename, "line" => $line_number

where C<$data> is a hash reference mapping column names to data values.

Default value: undef

=item header_callback

=item preprocess

Hash reference mapping column names to code references. These will be called
for the corresponding values for each data line, with C<$_> set to the value.
The output will be used to modify the data value.

=back

=head2 parse ($filename, $filehandle, $vcf)

Parses the given file. If C<$filehandle> is not provided, C<$filename> will
be opened automatically.

C<$vcf> can be used to specify whether the file is a VCF file. By default,
this will be auto-detected based on the filename's extension.

=cut

package PhyloSNP::Parser::CSV;

use strict;
use warnings;

use Carp;
use Text::CSV;

our %default_attr = (
    callback => undef,
    header_callback => undef,
    required => [],
    optional => [],
    preprocess => {}
);

our @required_attr = qw(callback);

sub new {
    my $class = shift;
    my %attr = @_;
    my $self = {%default_attr};
    for (keys %attr) {
        die "Unknown attribute '$_'" unless exists $default_attr{$_};
        $self->{$_} = $attr{$_};
    }
    for (@required_attr) {
        die "Missing required attribute '$_'" unless defined $self->{$_};
    }
    bless $self, $class;
    return $self;
}

sub parse {
    my $self = shift;
    my $fn = shift;
    my $fh = shift;
    my $vcf = shift;

    unless (defined $vcf) {
        $vcf = ($fn =~ /\.vcf$/i);
    }

    unless ($fh) {
        open $fh, $fn or confess "Failed to open '$fn'\n";
    }

    my $sep_char = ',';
    $sep_char = "\t" if $vcf;
    my $tcsv = Text::CSV->new({sep_char => $sep_char}) or confess "Failed to load Text::CSV\n";

    my $line = -1;

    # parse the header
    while (<$fh>) {
        $line++;

        if ($vcf) {
            # skip VCF metadata lines
            next if /^##/;
            # uncomment header line
            s/^#//;
        }

        # parse the header
        $tcsv->parse($_) or confess "Failed to parse line " . ($line+1) . " of $fn: " . $tcsv->error_diag();
        my @header = $tcsv->fields();

        # sanity checks
        my %column_count = map { $_ => 0 } @header;
        my %optional = map { $_ => 1 } @{$self->{optional}};
        my %required = map { $_ => 1 } @{$self->{required}};
        for (@header) {
            $column_count{$_}++;
            if ($column_count{$_} > 1 and ($required{$_} or $optional{$_})) {
                confess "Failed to parse $fn header: multiple columns with name '$_'\n";
            }
        }
        for (@{$self->{required}}) {
            confess "Failed to parse $fn header: missing required column '$_'\n" unless $column_count{$_};
        }

        $tcsv->column_names(@header);
        if ($self->{header_callback}) {
            $self->{header_callback}->(@header);
        }
        last;
    }

    # parse data lines
    while(my $data = $tcsv->getline_hr($fh)) {
        $line++;
        for (@{$self->{required}}) {
            unless (defined $data->{$_}) {
                confess "Failed to parse line " . ($line+1) . " of $fn: missing data for required column '$_'\n";
            }
        }

        for my $col (keys %{$self->{preprocess}}) {
            local $_ = $data->{$col};
            $data->{$col} = $self->{preprocess}->{$col}($col);
        }
        $self->{callback}->($data, filename => $fn, line => $line);
    }
    unless ($tcsv->eof()) {
        confess "Failed to parse line " . ($line+1) . " of $fn: " . $tcsv->error_diag();
    }

  out:
    close $fh;
    return $line+1;
}

#vim: set et ts=4 sts=4:
